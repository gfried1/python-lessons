class Boat(object):


	def __init__(self, length, letter, number):

		self.length=length
		self.letter=letter
		self.number=number


# if letter.number = board row column put y